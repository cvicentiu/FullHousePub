from django.contrib import admin
from fullhousepub.core.menu.models import *

admin.site.register(MenuItem)
admin.site.register(Detail)
