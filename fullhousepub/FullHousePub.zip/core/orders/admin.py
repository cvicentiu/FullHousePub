from django.contrib import admin
from fullhousepub.core.orders.models import *

admin.site.register(Buyer)
admin.site.register(Item)
admin.site.register(Order)
