from django.contrib import admin
from fullhousepub.core.customers.models import *

admin.site.register(CustomerPerson)
admin.site.register(CustomerFirm)
