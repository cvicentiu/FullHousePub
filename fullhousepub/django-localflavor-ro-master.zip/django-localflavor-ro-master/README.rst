=====================
django_localflavor_ro
=====================

Country-specific Django helpers for Romania.

What's in the Romania localflavor?
=================================

* forms.ROCIFField: A form field that validates Romanian fiscal identification
  codes (CIF). The return value strips the leading RO, if given.

* forms.ROCNPField: A form field that validates Romanian personal numeric
  codes (CNP).

* forms.ROCountyField: A form field that validates its input as a Romanian
  county (judet) name or abbreviation. It normalizes the input to the standard
  vehicle registration abbreviation for the given county. This field will only
  accept names written with diacritics; consider using ROCountySelect as an
  alternative.

* forms.ROCountySelect: A ``Select`` widget that uses a list of Romanian
  counties (judete) as its choices.

* forms.ROIBANField: A form field that validates its input as a Romanian
  International Bank Account Number (IBAN). The valid format is
  ROXX-XXXX-XXXX-XXXX-XXXX-XXXX, with or without hyphens.

* forms.ROPhoneNumberField: A form field that validates Romanian phone numbers,
  short special numbers excluded.

* forms.ROPostalCodeField: A form field that validates Romanian postal codes.

See the source code for full details.

About localflavors
==================

Django's "localflavor" packages offer additional functionality for particular
countries or cultures.

For example, these might include form fields for your country's postal codes,
phone number formats or government ID numbers.

This code used to live in Django proper -- in django.contrib.localflavor -- but
was separated into standalone packages in Django 1.5 to keep the framework's
core clean.

For a full list of available localflavors, see https://github.com/django/
